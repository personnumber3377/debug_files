#include <windows.h>
#include <iostream>
#include <vector>
#include <fstream>

// Typedefs for function pointers
typedef HRESULT (__stdcall *ISVGImageFactoryCreate1Proxy_t)(void**);
typedef HRESULT (__thiscall *CreateSVGImage_t)(void*, void**);
typedef void (__thiscall *DestroyFunc)(void*);

HMODULE hDll;
ISVGImageFactoryCreate1Proxy_t ISVGImageFactoryCreate1Proxy;

/*
void PrintLastError(const char* message) {
    DWORD errorCode = GetLastError();
    LPVOID errorMessage;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, errorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&errorMessage, 0, NULL);

    std::cerr << message << " Error Code: " << errorCode << " - " << (char*)errorMessage << std::endl;
    LocalFree(errorMessage);
}


void PrintLastErrorWithModule() {
    DWORD error = GetLastError();  // Get the last error code
    if (error == 126) {
        std::cerr << "Error 126: Module not found (missing dependency)" << std::endl;
    } else if (error == 193) {
        std::cerr << "Error 193: Incorrect architecture (x86 vs x64 mismatch)" << std::endl;
    } else {
        std::cerr << "Unknown error: " << error << std::endl;
    }

    LPVOID messageBuffer;
    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, error, 0, (LPTSTR)&messageBuffer, 0, NULL);

    std::cerr << "Error Message: " << (char*)messageBuffer << std::endl;
    LocalFree(messageBuffer);
}

*/


void PrintLastError() {
    DWORD error = GetLastError();
    if (error == 126) {
        std::cerr << "Error 126: Module not found (missing dependency)" << std::endl;
    } else if (error == 193) {
        std::cerr << "Error 193: Incorrect architecture (x86 vs x64 mismatch)" << std::endl;
    } else {
        std::cerr << "Unknown error: " << error << std::endl;
    }

    LPVOID messageBuffer;
    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL, error, 0, (LPSTR)&messageBuffer, 0, NULL);

    std::cerr << "Error Message: " << (char*)messageBuffer << std::endl;
    LocalFree(messageBuffer);
}

// Function to print which module is failing
void PrintMissingDependency(const std::wstring& moduleName) {
    HMODULE hModule = LoadLibraryExW(moduleName.c_str(), NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    if (!hModule) {
        DWORD error = GetLastError();
        std::wcerr << L"Failed to load: " << moduleName << L" - Error " << error << std::endl;
    } else {
        std::wcout << L"Successfully loaded: " << moduleName << std::endl;
        FreeLibrary(hModule);
    }
}

/*

Microsoft (R) COFF/PE Dumper Version 14.42.34436.0
Copyright (C) Microsoft Corporation.  All rights reserved.


Dump of file mso40uiWin32Client.dll

File Type: DLL

  Image has the following dependencies:

    KERNEL32.dll
    gdiplus.dll
    Mso30Win32Client.dll
    Mso20Win32Client.dll
    VCRUNTIME140_1.dll
    VCRUNTIME140.dll
    MSVCP140.dll
    api-ms-win-crt-heap-l1-1-0.dll
    api-ms-win-crt-convert-l1-1-0.dll
    api-ms-win-crt-runtime-l1-1-0.dll
    api-ms-win-crt-string-l1-1-0.dll
    api-ms-win-crt-stdio-l1-1-0.dll
    api-ms-win-crt-utility-l1-1-0.dll
    api-ms-win-crt-math-l1-1-0.dll
    api-ms-win-crt-filesystem-l1-1-0.dll
    api-ms-win-crt-time-l1-1-0.dll
    api-ms-win-crt-locale-l1-1-0.dll
    api-ms-win-crt-multibyte-l1-1-0.dll
    api-ms-win-crt-environment-l1-1-0.dll

  Image has the following delay load dependencies:

    dbghelp.dll
    ADVAPI32.dll
    d3d10_1.dll
    d3d11.dll
    d2d1.dll
    DWrite.dll
    dwmapi.dll
    dxgi.dll
    GDI32.dll
    NInput.dll
    OLEACC.dll
    ole32.dll
    USER32.dll
    VERSION.dll
    WindowsCodecs.dll
    WINMM.dll
    dcomp.dll
    api-ms-win-core-winrt-string-l1-1-0.dll
    api-ms-win-core-winrt-l1-1-0.dll
    api-ms-win-core-winrt-error-l1-1-0.dll
    MF.dll
    MFPlat.DLL
    msi.dll
    MSIMG32.dll
    OLEAUT32.dll
    POWRPROF.dll
    SHELL32.dll
    SHLWAPI.dll
    UIAutomationCore.DLL
    UxTheme.dll
    WINHTTP.dll
    WTSAPI32.dll
    XmlLite.dll
    react-native-win32.dll
    Microsoft.UI.Windowing.Core.dll
    WebView2Loader.dll

  Summary

       4C000 .data
        3000 .detourc
        2000 .didat
       85000 .pdata
      6F6000 .rdata
       3A000 .reloc
        1000 .rsrc
      972000 .text

*/

// Function to load DLL and get function pointers
int fuzz_init(void) {
    // C:\Program Files\Microsoft Office\root\vfs\ProgramFilesCommonX64\Microsoft Shared\
    // this was previously C:\\Program Files\\Microsoft Office\\root\\Office16\\
    // SetDllDirectory("C:\\Program Files\\Microsoft Office\\root\\vfs\\ProgramFilesCommonX64\\Microsoft Shared\\"); // We need to look here

    /*
    hDll = LoadLibrary("MSOSVG.DLL");
    if (!hDll) {
        // std::cerr << "Failed to load MSOSVG.DLL\n";
        PrintLastError("Failed to load MSOSVG.DLL\n");
        return 1;
    }*/


    // HMODULE hDll = LoadLibraryEx("MSOSVG.dll", NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    // Try loading with explicit error detection
    // HMODULE hDll = LoadLibraryExW(L"MSOSVG.dll", NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    // mso40uiWin32Client.dll
    // HMODULE hDll = LoadLibraryExW(L"mso40uiWin32Client.dll", NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
    HMODULE hDll = LoadLibraryW(L"MSOSVG.dll");
    if (!hDll) {
        std::cerr << "Failed to load MSOSVG.DLL" << std::endl;
        PrintLastError();

        // Now manually check each dependency
        /*
        std::vector<std::wstring> dependencies = {
            L"KERNEL32.dll",
            L"OLEAUT32.dll",
            L"mso40uiWin32Client.dll",
            L"Mso20Win32Client.dll",
            L"VCRUNTIME140_1.dll",
            L"VCRUNTIME140.dll",
            L"MSVCP140.dll",
            L"api-ms-win-crt-heap-l1-1-0.dll",
            L"api-ms-win-crt-runtime-l1-1-0.dll",
            L"api-ms-win-crt-string-l1-1-0.dll",
            L"api-ms-win-crt-stdio-l1-1-0.dll",
            L"api-ms-win-crt-math-l1-1-0.dll",
            L"api-ms-win-crt-convert-l1-1-0.dll",
            L"api-ms-win-crt-locale-l1-1-0.dll",
            L"gfx.dll"  // Delay-loaded dependency
        };





                };

        std::vector<std::wstring> delay_load_dependencies = {
        */



        std::vector<std::wstring> dependencies = {
            L"KERNEL32.dll",
            L"gdiplus.dll",
            L"Mso30Win32Client.dll",
            L"Mso20Win32Client.dll",
            L"VCRUNTIME140_1.dll",
            L"VCRUNTIME140.dll",
            L"MSVCP140.dll",
            L"api-ms-win-crt-heap-l1-1-0.dll",
            L"api-ms-win-crt-convert-l1-1-0.dll",
            L"api-ms-win-crt-runtime-l1-1-0.dll",
            L"api-ms-win-crt-string-l1-1-0.dll",
            L"api-ms-win-crt-stdio-l1-1-0.dll",
            L"api-ms-win-crt-utility-l1-1-0.dll",
            L"api-ms-win-crt-math-l1-1-0.dll",
            L"api-ms-win-crt-filesystem-l1-1-0.dll",
            L"api-ms-win-crt-time-l1-1-0.dll",
            L"api-ms-win-crt-locale-l1-1-0.dll",
            L"api-ms-win-crt-multibyte-l1-1-0.dll",
            L"api-ms-win-crt-environment-l1-1-0.dll",
            L"dbghelp.dll",
            L"ADVAPI32.dll",
            L"d3d10_1.dll",
            L"d3d11.dll",
            L"d2d1.dll",
            L"DWrite.dll",
            L"dwmapi.dll",
            L"dxgi.dll",
            L"GDI32.dll",
            L"NInput.dll",
            L"OLEACC.dll",
            L"ole32.dll",
            L"USER32.dll",
            L"VERSION.dll",
            L"WindowsCodecs.dll",
            L"WINMM.dll",
            L"dcomp.dll",
            L"api-ms-win-core-winrt-string-l1-1-0.dll",
            L"api-ms-win-core-winrt-l1-1-0.dll",
            L"api-ms-win-core-winrt-error-l1-1-0.dll",
            L"MF.dll",
            L"MFPlat.DLL",
            L"msi.dll",
            L"MSIMG32.dll",
            L"OLEAUT32.dll",
            L"POWRPROF.dll",
            L"SHELL32.dll",
            L"SHLWAPI.dll",
            L"UIAutomationCore.DLL",
            L"UxTheme.dll",
            L"WINHTTP.dll",
            L"WTSAPI32.dll",
            L"XmlLite.dll",
            L"react-native-win32.dll",
            L"Microsoft.UI.Windowing.Core.dll",
            L"WebView2Loader.dll"
        };


        std::wcout << L"Checking dependencies...\n";
        for (const auto& dep : dependencies) {
            PrintMissingDependency(dep);
        }

        return 1;
    }

    printf("Holy fuck!!!\n");
    ISVGImageFactoryCreate1Proxy = 
        (ISVGImageFactoryCreate1Proxy_t) GetProcAddress(hDll, "ISVGImageFactoryCreate1Proxy");

    if (!ISVGImageFactoryCreate1Proxy) {
        std::cerr << "Failed to get function address for ISVGImageFactoryCreate1Proxy\n";
        FreeLibrary(hDll);
        return 1;
    }

    return 0;
}

// Function to read a file into a buffer
bool ReadFileToBuffer(const std::string& filename, std::vector<uint8_t>& buffer) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error: Could not open file: " << filename << "\n";
        return false;
    }

    file.seekg(0, std::ios::end);
    size_t fileSize = file.tellg();
    file.seekg(0, std::ios::beg);

    if (fileSize < 1) { // Ensure there is data
        std::cerr << "Error: File must not be empty!\n";
        return false;
    }

    buffer.resize(fileSize);
    file.read(reinterpret_cast<char*>(buffer.data()), fileSize);
    return true;
}

// Function to call CreateSVGImage
int fuzz_function(const std::vector<uint8_t>& svgData) {
    void* factory = nullptr;
    void* svgImage = nullptr;
    HRESULT res;
    // Call the factory function to get an instance of ISVGImageFactory // NOTE: This actually returns void, therefore do not check res
    // HRESULT res = ISVGImageFactoryCreate1Proxy(&factory);
    ISVGImageFactoryCreate1Proxy(&factory);
    printf("Here is the factory pointer: %p\n", factory);
    //if (FAILED(res) || !factory) {
    if (!factory) {
        std::cerr << "Error: Failed to get SVGImageFactory!\n";
        return 1;
    }



    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr)) {
        std::cerr << "CoInitialize failed: " << std::hex << hr << std::endl;
        return 1;
    }

    // Read the input file into a buffer.
    std::ifstream file("input.svg", std::ios::binary);
    if (!file) {
        std::cerr << "Failed to open input file: " << "input.svg" << std::endl;
        CoUninitialize();
        return 1;
    }
    std::vector<BYTE> buffer((std::istreambuf_iterator<char>(file)),
                             std::istreambuf_iterator<char>());
    file.close();


    // Create an IStream from the buffer.
    IStream* pStream = SHCreateMemStream(buffer.data(), static_cast<UINT>(buffer.size()));
    if (!pStream) {
        std::cerr << "SHCreateMemStream failed." << std::endl;
        CoUninitialize();
        return 1;
    }


    // Get the function pointer for CreateSVGImage from the vtable
    void** vtable_ptr = *(void***)factory;
    CreateSVGImage_t create_svg_func = (CreateSVGImage_t)vtable_ptr[5]; // Usually function at index 5

    if (!create_svg_func) {
        std::cerr << "Error: Failed to retrieve CreateSVGImage function pointer!\n";
        return 1;
    }

    // Call CreateSVGImage


    // Prepare an output pointer to receive the SVGImage.
    //void* svgImage = nullptr;
    
    create_svg_func(&svgImage, pStream);
    
    printf("Here is the bullshit: %p\n", svgImage);
    return 0;

    /*
    if (FAILED(hr)) {
        std::cerr << "CreateSVGImage failed: " << std::hex << hr << std::endl;
    } else {
        std::cout << "CreateSVGImage succeeded. SVGImage pointer: " << svgImage << std::endl;
    }
    */


    /*
    res = create_svg_func(factory, &svgImage);
    printf("Here is the svgImage: %p\n", svgImage);

    if (FAILED(res) || !svgImage) {
        std::cerr << "CreateSVGImage failed!\n";
        return 1;
    }
    */


    std::cout << "Successfully created SVGImage!\n";

    // Cleanup: Destroy the created SVGImage if possible
    DestroyFunc destroy_func = (DestroyFunc)vtable_ptr[0]; // Assuming first function in vtable is destroy
    if (destroy_func) {
        destroy_func(svgImage);
    }

    return 0;
}

// Main fuzzing function
__declspec(noinline) void __fastcall actual_stuff(char* filename) {
    std::vector<uint8_t> buffer;

    if (!ReadFileToBuffer(filename, buffer)) {
        return;
    }

    fuzz_function(buffer);
}

// Loop for continuous fuzzing
__declspec(noinline) void __fastcall loop(char* filename) {
    actual_stuff(filename);
}

int main(int argc, char** argv) {
    if (fuzz_init()) {
        std::cerr << "Failed to initialize fuzzing setup\n";
        return 0;
    }

    if (argc != 2) {
        std::cerr << "Need to pass input file as command line argument!\n";
        return 0;
    }

    while (1) {
        loop(argv[1]);
    }

    FreeLibrary(hDll);
    return 0;
}