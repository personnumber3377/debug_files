'''
    Here is the jnz call bullshit:

           18000648e e8  99  eb       CALL       Mso::SVG::SVGImage::FUseCaching                  bool FUseCaching(void)
                 03  00
       180006493 84  c0           TEST       AL ,AL
       180006495 75  4e           JNZ        LAB_1800064e5
       180006497 ba  01  00       MOV        somestreamstuff ,0x1
                 00  00
       18000649c b9  a0  00       MOV        suspected_filename ,0xa0
                 00  00


    so therefore if we just patch the jnz out with nops, we should be good... correct?????

    84  c0  75  4e  ba  01  00  00  00  b9  a0  00   00  00


    "\x84\xc0\x75\x4e\xba\x01\x00\x00\x00\xb9\xa0\x00\x00\x00"
'''


def patch(orig_data):
	orig_needle = b"\x84\xc0\x75\x4e\xba\x01\x00\x00\x00\xb9\xa0\x00\x00\x00"

	new_needle = b"\x84\xc0\x90\x90\xba\x01\x00\x00\x00\xb9\xa0\x00\x00\x00"

	assert orig_data.count(orig_needle) == 1
	new_data = orig_data.replace(orig_needle, new_needle)
	return new_data


fh = open("MSOSVG.DLL", "rb")

orig_data = fh.read()

fh.close()


new_data = patch(orig_data)

fh = open("MODIFIED.DLL", "wb")

fh.write(new_data)
fh.close()

exit(0)


