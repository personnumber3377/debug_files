#include <windows.h>
#include <iostream>
#include <vector>
#include <gdiplus.h>
#include <fstream>

// For input handling
#include <string>
#include <iostream>

using namespace Gdiplus;

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")

typedef int (__stdcall *GetBarcodeRenderer_t)(int, void**);
typedef long (__thiscall *ValidateDataFunc)(void*, wchar_t*);
typedef long (__thiscall *DrawToDCFunc)(void*, HDC, RECT*, wchar_t*);
typedef void (__thiscall *DestroyFunc)(void*);

// Global variables used during fuzzing...

HMODULE hDll;
GetBarcodeRenderer_t GetBarcodeRenderer;




// Helper function to get the CLSID of an encoder (e.g., PNG)
int GetEncoderClsid(const WCHAR* format, CLSID* pClsid) {
    UINT num = 0, size = 0;
    GetImageEncodersSize(&num, &size);
    if (size == 0) return -1;

    ImageCodecInfo* pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
    if (!pImageCodecInfo) return -1;

    GetImageEncoders(num, size, pImageCodecInfo);
    for (UINT i = 0; i < num; i++) {
        if (wcscmp(pImageCodecInfo[i].MimeType, format) == 0) {
            *pClsid = pImageCodecInfo[i].Clsid;
            free(pImageCodecInfo);
            return 0;
        }
    }
    free(pImageCodecInfo);
    return -1;
}

int fuzz_init(void) {
    // Initialization function

    // Load MSBARCODE.DLL

    hDll = LoadLibrary("MSBARCODE.dll");
    if (!hDll) {
        printf("Failed to load DLL\n");
        std::cerr << "Failed to load DLL\n";
        return 1;
    }

    // Get function pointer for `GetBarcodeRenderer`
    GetBarcodeRenderer = 
        (GetBarcodeRenderer_t) GetProcAddress(hDll, "GetBarcodeRenderer");

    if (!GetBarcodeRenderer) {
        printf("Failed to get function address\n");
        std::cerr << "Failed to get function address\n";
        FreeLibrary(hDll);
        return 1;
    }
    return 0;
}



int draw_to_file(HDC hdcMem, HBITMAP hBitmap) {
    // Initialize GDI+
    GdiplusStartupInput gdiplusStartupInput;
    ULONG_PTR gdiplusToken;
    GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // Convert HBITMAP to Bitmap
    Bitmap* bmp = Bitmap::FromHBITMAP(hBitmap, NULL);
    if (!bmp || bmp->GetLastStatus() != Ok) {
        // printf("Error: Failed to create Bitmap object!\n");
        return 1;
    }

    // Save as PNG
    CLSID pngClsid;
    if (GetEncoderClsid(L"image/png", &pngClsid) != 0) {
        //printf("Error: Could not find PNG encoder!\n");
        return 1;
    }
    bmp->Save(L"barcode.png", &pngClsid, NULL);
    // printf("Barcode saved as 'barcode.png'\n");
    // Cleanup (do not delete objects which do not need to be deleted here)
    delete bmp;
    GdiplusShutdown(gdiplusToken);

}


int fuzz_function(int barcodeType, wchar_t* test_str) {

        // Call the function to get the renderer object
    void* renderer = nullptr;
    int result = GetBarcodeRenderer(barcodeType, &renderer);
    if (!renderer) {
        fprintf(stderr, "Error: Failed to get barcode renderer!\n");
        printf("Error: Failed to get barcode renderer!\n");
        FreeLibrary(hDll);
        return 1;
    }

    // Get vtable and function pointers
    void* vtable_ptr = *(void**)renderer;
    int function_offset = 8 * 5;  // At index 5
    int draw_function_offset = 8 * 7;  // At index 7

    ValidateDataFunc validate_func = *(ValidateDataFunc *)((char *)vtable_ptr + function_offset);
    DrawToDCFunc draw_func = *(DrawToDCFunc *)((char *)vtable_ptr + draw_function_offset);
    DestroyFunc destroy_func = *(DestroyFunc *)((char *)vtable_ptr + 0x0);

    if (!validate_func || !draw_func || !destroy_func) {
        // printf("Error: Failed to retrieve required function pointers!\n");
        FreeLibrary(hDll);
        return 1;
    }

    // Validate barcode data
    long res = validate_func(renderer, test_str);
    if (res != 0) {
        // printf("Invalid data passed. Returning...\n");
        return 1;
    }

    // Create a memory DC
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    ReleaseDC(NULL, hdcScreen);

    int width = 300, height = 100;
    HBITMAP hBitmap = CreateCompatibleBitmap(hdcMem, width, height);
    SelectObject(hdcMem, hBitmap);

    RECT rect = {0, 0, width, height};

    // Ensure the background is filled
    HBRUSH hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH);
    FillRect(hdcMem, &rect, hBrush);

    // Draw the barcode
    long res2 = draw_func(renderer, hdcMem, &rect, test_str);
    if (res2 != 0) {
        // printf("Error: DrawToDC failed! Exiting...\n");
        return 1;
    }

    // Here draw the stuff...

    // draw_to_file(hdcMem, hBitmap);


    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    // Destroy the renderer
    destroy_func(renderer);
    return 0;
}






bool ReadFileToBuffer(const std::string& filename, std::vector<uint8_t>& buffer) {
    std::ifstream file(filename, std::ios::binary);  // Open file in binary mode
    if (!file) {
        // std::cerr << "Error: Could not open file: " << filename << "\n";
        return false;
    }
    
    file.seekg(0, std::ios::end);  // Move to end of file
    size_t fileSize = file.tellg();  // Get file size
    file.seekg(0, std::ios::beg);  // Move back to beginning

    if (fileSize < 2) {  // Need at least 2 bytes for barcode processing
        //std::cerr << "Error: File must be at least 2 bytes long!\n";
        return false;
    }

    buffer.resize(fileSize);
    file.read(reinterpret_cast<char*>(buffer.data()), fileSize);
    return true;
}


int fuzz_function_no_check(int barcodeType, wchar_t* test_str) {
    // Now do the stuff...
    // This is to handle the special barcodeTypes which do not check for the stuff..


    // Call the function to get the renderer object
    void* renderer = nullptr;
    int result = GetBarcodeRenderer(barcodeType, &renderer);
    if (!renderer) {
        fprintf(stderr, "Error: Failed to get barcode renderer!\n");
        printf("Error: Failed to get barcode renderer!\n");
        FreeLibrary(hDll);
        return 1;
    }

    // Get vtable and function pointers
    void* vtable_ptr = *(void**)renderer;
    //int function_offset = 8 * 5;  // At index 5
    int draw_function_offset = 8 * 7;  // At index 7

    //ValidateDataFunc validate_func = *(ValidateDataFunc *)((char *)vtable_ptr + function_offset);
    DrawToDCFunc draw_func = *(DrawToDCFunc *)((char *)vtable_ptr + draw_function_offset);
    DestroyFunc destroy_func = *(DestroyFunc *)((char *)vtable_ptr + 0x0);

    if (!draw_func || !destroy_func) {
        // printf("Error: Failed to retrieve required function pointers!\n");
        FreeLibrary(hDll);
        return 1;
    }

    // Create a memory DC
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    ReleaseDC(NULL, hdcScreen);

    int width = 300, height = 100;
    HBITMAP hBitmap = CreateCompatibleBitmap(hdcMem, width, height);
    SelectObject(hdcMem, hBitmap);

    RECT rect = {0, 0, width, height};

    // Ensure the background is filled
    HBRUSH hBrush = (HBRUSH)GetStockObject(WHITE_BRUSH);
    FillRect(hdcMem, &rect, hBrush);

    // Draw the barcode
    long res2 = draw_func(renderer, hdcMem, &rect, test_str);
    if (res2 != 0) {
        // printf("Error: DrawToDC failed! Exiting...\n");
        return 1;
    }

    // Here draw the stuff...

    // draw_to_file(hdcMem, hBitmap);


    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    // Destroy the renderer
    destroy_func(renderer);
    return 0;
}



__declspec(noinline) void __fastcall actual_stuff(char* filename) {
    // Now just do the stuff...

    // Read input from stdin

    /*
    std::string input;
    std::getline(std::cin, input);

    if (input.size() < 2) {  // Need at least 2 bytes (1 for type, rest for barcode data)
        std::cerr << "Error: Input must be at least 2 bytes long!\n";
        // return 1;
        return;
    }

    // Extract first byte for barcode type and remove it from input
    int barcodeType = static_cast<unsigned char>(input[0]) % 12;
    input = input.substr(1);  // Remove first byte

    // Ban barcode types 8 and 9
    if (barcodeType == 8 || barcodeType == 9) {
        printf("Error: Barcode type %d is banned!\n", barcodeType);
        // return 1;
        return;
    }

    // Convert remaining input to wide string (wchar_t*)
    std::vector<wchar_t> winput(input.begin(), input.end());
    winput.push_back(L'\0');  // Null-terminate
    wchar_t* test_str = winput.data();

    */



    std::vector<uint8_t> buffer;

    if (!ReadFileToBuffer(filename, buffer)) {
        // return 1;
        return;
    }



    // Extract first byte for barcode type and remove it
    int barcodeType = buffer[0] % 12;
    buffer.erase(buffer.begin());  // Remove first byte

    // Ban barcode types 8 and 9
    /*
    if (barcodeType == 8 || barcodeType == 9) {
        // printf("Error: Barcode type %d is banned!\n", barcodeType);
        //return 1;
        return;
    }
    */

    // Convert the remaining buffer to a wide string (wchar_t*)
    std::vector<wchar_t> winput(buffer.begin(), buffer.end());
    winput.push_back(L'\0');  // Null-terminate
    wchar_t* test_str = winput.data();

    // printf("Barcode Type: %d\n", barcodeType);
    // printf("Data Length: %zu bytes\n", buffer.size());

    if (barcodeType == 8 || barcodeType == 9) {
        fuzz_function_no_check(barcodeType, test_str);
        return;
    }

    fuzz_function(barcodeType, test_str);


    return;
}


// __declspec(noinline) void __fastcall loop(wchar_t* filename) {
// std::string
__declspec(noinline) void __fastcall loop(char* filename) {

    actual_stuff(filename);
    return;
}

void writeToFile(const std::string& filename, const std::string& content) {
    std::ofstream file(filename, std::ios::out | std::ios::binary);
    file << content;
}


int main(int argc, char** argv) {
    //printf("Called main...\n");
    if (fuzz_init()) {
        // Call fuzz init...
        printf("failed the shit\n");
        //writeToFile("pooopooooooo.bin", "failed the shit\n");
        return 0;
    }
    //printf("After the shit...\n");

    



    // fuzz_function(barcodeType, test_str);

    if (argc != 2) {
        printf("Need to pass input file as command line argument!!!\n");
        return 0;
    }


    // loop(argv[1]);
    //printf("FUUUUUCCCKCKCKCKCKCKKCKCKCKCKCKKCKCKCKCKCKCCKCK\n");
    //printf("poopooo\n");
    while (1) {
        //printf("FUUUUUCCCKCKCKCKCKCKKCKCKCKCKCKKCKCKCKCKCKCCKCK\n");
        //writeToFile("pooopooooooo.bin", "FUUUUUCCCKCKCKCKCKCKKCKCKCKCKCKKCKCKCKCKCKCCKCK\n");
        loop(argv[1]);
    }



    FreeLibrary(hDll);
    return 0;
}